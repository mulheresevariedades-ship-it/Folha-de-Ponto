import uvicorn


def main() -> None:
    uvicorn.run("server:app", host="0.0.0.0", port=5000, reload=False)


if __name__ == "__main__":
    main()
